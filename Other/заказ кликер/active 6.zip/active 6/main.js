let countDisplay = document.getElementById("count");
let fullCounter = document.getElementById("fullCounter");

function changeImage() {
    const startElement = document.getElementById('start');
    startElement.style.backgroundImage = 'url("pushin_2.gif")'; // Здесь нужно заменить на путь к вашему gif

    // Через 0.3 секунды возвращаем исходное изображение (jpg)
    setTimeout(function() {
        startElement.style.backgroundImage = 'url("pushin_1.png")'; // Здесь нужно заменить на путь к вашему jpg
    }, 1200);
}

// Обработчик нажатия на кнопку старта
document.body.addEventListener('mousedown', () => {
    isButtonPressed = true;
    incrementCounter();
    updateJSON();
});

// Обработчик отпускания кнопки старта
document.body.addEventListener('mouseup', () => {
    isButtonPressed = false;
});

// Функция для увеличения счетчика
function incrementCounter() {
    let currentValue = parseInt(countDisplay.textContent);
    countDisplay.textContent = currentValue + 1;
}

// Функция для обновления JSON на сервере
function updateJSON() {
    // Отправляем GET-запрос на сервер для получения текущего значения fullCounter из JSON
    fetch('http://192.168.0.108:52330/Other/заказ%20кликер/active%206/players.json')
    .then(response => {
        if (!response.ok) {
            throw new Error('Ошибка при получении данных с сервера');
        }
        return response.json();
    })
    .then(data => {
        // Увеличиваем значение fullCounter на количество кликов
        data.fullCounter.clicks += 1;

        // Обновляем значение fullCounter на странице
        fullCounter.textContent = data.fullCounter.clicks;

        // Отправляем POST-запрос на сервер для обновления JSON с новым значением fullCounter
        return fetch('http://192.168.0.108:52330/Other/заказ%20кликер/active%206/players.json', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(data)
        });
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Ошибка при отправке данных на сервер');
        }
        return response.json();
    })
    .then(data => {
        console.log('Данные успешно отправлены на сервер:', data);
    })
    .catch(error => {
        console.error('Произошла ошибка:', error);
    });
}