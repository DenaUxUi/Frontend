// switch(num){
//     case 5:{
//         console.log('мало');
//         break;
//     }
//     case 6:{
//         console.log('в точку');
//         break;
//     }
//     case 7:{
//         console.log('много');
//         break;
//     }
//     default:{
//         console.log('таких значений нет');
//     }
// }

let num = 1; 

num > 2
    ? console.log("Hello world")
    : num < 0
    ? console.log("Hello geeks")
    : console.log("Hello!");