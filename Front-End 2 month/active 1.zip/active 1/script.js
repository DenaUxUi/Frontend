// {
// let box = 100 /* Переменная */
// const b = 15; /* ПОСТОЯННА  */
// var с = 20; /* Вариативная */ /* НЕ ТРОГАТЬ */
// }

// let homeNumber = 45;
// console.log(number);

let str = "Hello World!";
let num = 10;
let bool = true;
let n = null;
let u = undefined;
let obj = {};